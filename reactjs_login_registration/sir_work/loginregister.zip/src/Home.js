const Home=()=>{
    return(
        <div>
              Welcome to Home Page
        </div>
    )
}

export default Home;